import React, { useEffect, useState, useMemo } from 'react';
import { StyleSheet, View, Text, Platform } from 'react-native';
import { Canvas, Path, Points, vec, Skia, SkPath } from '@shopify/react-native-skia';
import { useSystem } from '../system/SystemContext';
import { colors } from '../theme/colors';

export interface NeuralBackgroundProps {
  className?: string; // For compatibility
}

export const NeuralBackground: React.FC<NeuralBackgroundProps> = () => {
  const { engine, theme } = useSystem();

  const [nodePoints, setNodePoints] = useState<any[]>([]);
  const [activeNodePoints, setActiveNodePoints] = useState<any[]>([]);
  const [edgesPath, setEdgesPath] = useState<SkPath | null>(null);
  const [activeEdgesPath, setActiveEdgesPath] = useState<SkPath | null>(null);
  const [fps, setFps] = useState(60);

  // Theme colors
  const activeColor = colors[theme].accent;
  const inactiveColor = 'rgba(255, 255, 255, 0.1)';
  const nodeColor = 'rgba(255, 255, 255, 0.2)';
  const activeNodeColor = colors[theme].accent;

  const baseSkPath = useMemo(() => Skia.Path.Make(), []);
  const activeSkPath = useMemo(() => Skia.Path.Make(), []);
  const [forceRender, setForceRender] = useState(0);

  useEffect(() => {
    if (!engine) return;

    let frameCount = 0;
    let lastFpsUpdate = Date.now();
    let lastRenderUpdate = Date.now();

    const unsubscribe = engine.subscribe((state) => {
      const { nodes, edges, activeEdges } = state;

      // FPS tracking
      frameCount++;
      const now = Date.now();
      if (now - lastFpsUpdate > 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastFpsUpdate = now;
      }

      // Throttle rendering to ~30fps to prevent Hermes/JSI crash
      if (now - lastRenderUpdate < 33) {
        return;
      }
      lastRenderUpdate = now;

      // 1. Prepare Node Points
      const standardPoints: any[] = [];
      const energizedPoints: any[] = [];

      nodes.forEach((n) => {
        const pt = vec(n.position[0], n.position[1]);
        if (n.energy > 0.2) {
          energizedPoints.push(pt);
        } else {
          standardPoints.push(pt);
        }
      });

      // 2. Prepare Edges Paths (Reuse paths)
      baseSkPath.reset();
      activeSkPath.reset();

      edges.forEach((edge) => {
        const nodeA = nodes[edge.from];
        const nodeB = nodes[edge.to];
        if (nodeA && nodeB) {
          const edgeId = [edge.from, edge.to].sort((a, b) => a - b).join('-');
          if (activeEdges.has(edgeId)) {
            activeSkPath.moveTo(nodeA.position[0], nodeA.position[1]);
            activeSkPath.lineTo(nodeB.position[0], nodeB.position[1]);
          } else {
            baseSkPath.moveTo(nodeA.position[0], nodeA.position[1]);
            baseSkPath.lineTo(nodeB.position[0], nodeB.position[1]);
          }
        }
      });

      // 3. Update States
      setNodePoints(standardPoints);
      setActiveNodePoints(energizedPoints);
      setEdgesPath(baseSkPath);
      setActiveEdgesPath(activeSkPath);
      setForceRender(prev => prev + 1);
    });

    return () => {
      unsubscribe();
    };
  }, [engine, baseSkPath, activeSkPath]);

  const bgStyle = useMemo(() => {
    return {
      backgroundColor: colors[theme].bg,
    };
  }, [theme]);

  return (
    <View style={[StyleSheet.absoluteFill, bgStyle]}>
      <Canvas style={StyleSheet.absoluteFill}>
        {/* Active Energized Edges (Glow effect) - We don't render passive edges anymore to keep the UI clean */}
        {activeEdgesPath && (
          <Path
            path={activeEdgesPath}
            color={activeColor}
            style="stroke"
            strokeWidth={1.5}
          />
        )}

        {/* Standard Nodes */}
        {nodePoints.length > 0 && (
          <Points
            points={nodePoints}
            mode="points"
            color={nodeColor}
            strokeWidth={2}
          />
        )}

        {/* Energized Active Nodes */}
        {activeNodePoints.length > 0 && (
          <Points
            points={activeNodePoints}
            mode="points"
            color={activeNodeColor}
            strokeWidth={4.5}
          />
        )}
      </Canvas>

      {/* Futuristic HUD overlay info */}
      <View style={styles.hudContainer}>
        <Text style={[styles.hudText, { color: activeColor }]}>
          SYSTEM_LOAD: {fps} FPS // {theme.toUpperCase()}_NATIVE_MODE
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  hudContainer: {
    position: 'absolute',
    top: 40,
    right: 20,
    opacity: 0.4,
  },
  hudText: {
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    fontSize: 9,
    letterSpacing: 1.5,
  },
});
